from django.db import models

class Customer(models.Model):
    customer_id = models.IntegerField(primary_key=True)
    customer_name = models.CharField(max_length=100)
    msisdn = models.CharField(max_length=15)
    class Meta:
        managed = True
        db_table = 'customer'

class CallRecord(models.Model):
    msisdn = models.CharField(max_length=15)
    imsi = models.CharField(max_length=15)
    imei = models.CharField(max_length=15)
    plan = models.CharField(max_length=50)
    call_type = models.CharField(max_length=10)
    corresp_type = models.CharField(max_length=10)
    corresp_isdn = models.CharField(max_length=15)
    duration = models.IntegerField()
    time = models.TimeField()
    date = models.DateField()
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='call_records')

    class Meta:
        managed = True
        db_table = 'callrecord'
