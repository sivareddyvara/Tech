import csv
from datetime import datetime
from rest_framework import generics
from rest_framework.response import Response
from rest_framework import status
from .models import Customer, CallRecord
from .serializers import CustomerSerializer, CallRecordSerializer
from .serializers import FileUploadSerializer
from datetime import datetime
from rest_framework import viewsets

class CustomerViewSet(viewsets.ModelViewSet):
    serializer_class = CustomerSerializer
    queryset = Customer.objects.all()

class CallRecordViewSet(viewsets.ModelViewSet):
    serializer_class = CallRecordSerializer
    queryset = CallRecord.objects.all()

class UploadDataView(generics.GenericAPIView):
    serializer_class = FileUploadSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        customer_file = serializer.validated_data['customer_file']
        call_record_file = serializer.validated_data['call_record_file']

        self.handle_customer_file(customer_file)
        self.handle_call_record_file(call_record_file)

        return Response({"message": "Files processed successfully"}, status=status.HTTP_201_CREATED)

    def handle_customer_file(self, customer_file):
        decoded_file = customer_file.read().decode('utf-8').splitlines()
        reader = csv.reader(decoded_file, delimiter=':')

        header = next(reader, None)  # Skip header row
        if header is None or len(header) != 3:
            raise ValueError("Invalid customer file format")

        for row in reader:
            if len(row) != 3:
                continue  # Skip invalid rows
            customer_id = int(row[0])
            if not Customer.objects.filter(customer_id=customer_id).exists():
                Customer.objects.create(
                    customer_id=customer_id,
                    customer_name=row[1],
                    msisdn=row[2]
                )

    def handle_call_record_file(self, call_record_file):
        decoded_file = call_record_file.read().decode('utf-8').splitlines()
        print(decoded_file)
        data_lines = decoded_file[1:]
        row = [i.split(':',8) for i in data_lines]
        values=[]
        for i in row:
            val=[]
            for j in i:
                if j==i[-1]:
                    a=j.rsplit(':',1)
                    val.extend(a)
                else:
                     val.append(j)
            values.append(val)
        print(values)
        reader = values

        for row in reader:

            if len(row) != 10:
                continue  # Skip invalid rows
            try:
                customer = Customer.objects.get(msisdn=row[0])
                CallRecord.objects.create(
                    msisdn=row[0],
                    imsi=row[1],
                    imei=row[2],
                    plan=row[3],
                    call_type=row[4],
                    corresp_type=row[5],
                    corresp_isdn=row[6],
                    duration=int(row[7]),
                    time=row[8],
                    date=datetime.strptime(row[9], '%Y-%m-%d').date() if '-' in row[9] else datetime.strptime(row[9],
                                                                                                              '%d/%m/%Y').date(),
                    customer=customer
                )
            except Customer.DoesNotExist:
                print(f"Customer with MSISDN {row[0]} does not exist")
            except ValueError as e:
                print(f"Error processing row {row}: {e}")

