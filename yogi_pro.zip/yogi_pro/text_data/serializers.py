from rest_framework import serializers
from text_data.models import Customer, CallRecord

class CallRecordSerializer(serializers.ModelSerializer):
    class Meta:
        model = CallRecord
        fields = '__all__'

class CustomerSerializer(serializers.ModelSerializer):
    call_records = CallRecordSerializer(many=True, read_only=True)

    class Meta:
        model = Customer
        fields = '__all__'

class FileUploadSerializer(serializers.Serializer):
    customer_file = serializers.FileField()
    call_record_file = serializers.FileField()

